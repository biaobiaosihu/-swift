//
//  Block.swift
//  Swift俄罗斯方块
//
//  Created by biao on 2017/4/24.
//  Copyright © 2017年 xbgph. All rights reserved.
//

import UIKit

struct Block {
    var x: Int
    var y:Int
    var color:Int 
    
    
}
